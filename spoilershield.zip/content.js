// Spoiler Shield v3 - Content Script

function createShieldHTML() {
  return `
    <div class="ss-shield-inner">
      <div class="ss-shield-logo">🛡️</div>
      <div class="ss-shield-title">SpoilerShield</div>
      <div class="ss-shield-subtitle">Filtering spoilers...</div>
      <div class="ss-shield-spinner"></div>
    </div>
  `;
}

let shieldShownAt = Date.now();
let shieldRemoved = false;
let scanComplete = false;

function injectShield() {
  const existing = document.getElementById('ss-page-shield');
  if (existing) existing.remove();
  const s = document.createElement('div');
  s.id = 'ss-page-shield';
  s.innerHTML = createShieldHTML();
  document.documentElement.appendChild(s);
  shieldShownAt = Date.now();
  shieldRemoved = false;
  scanComplete = false;

  setTimeout(() => {
    scanComplete = true;
    removeShield();
  }, 6000);
}

function removeShield() {
  if (shieldRemoved) return;
  const elapsed = Date.now() - shieldShownAt;
  const remaining = Math.max(0, 2000 - elapsed);

  setTimeout(() => {
    if (shieldRemoved) return;
    if (!scanComplete) {
      setTimeout(() => removeShield(), 100);
      return;
    }
    shieldRemoved = true;
    const s = document.getElementById('ss-page-shield');
    if (s) {
      s.classList.add('fade-out');
      setTimeout(() => s.remove(), 200);
    }
  }, remaining);
}

// Re-show shield on YouTube navigation (SPA page changes)
let lastUrl = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    // Only re-inject if teams are selected
    chrome.storage.local.get(['selectedTeams', 'enabled'], data => {
      const selectedTeams = data.selectedTeams || [];
      const enabled = data.enabled !== false;
      if (selectedTeams.length > 0 && enabled) {
        injectShield();
      }
    });
  }
}).observe(document.body, { childList: true, subtree: true });

let blockedTeams = [];
let isEnabled = true;

// Load settings from storage
function loadSettings(callback) {
  chrome.storage.local.get(['spoilerData', 'selectedTeams', 'enabled'], data => {
    const spoilerData = data.spoilerData;
    const selectedIds = new Set(data.selectedTeams || []);
    isEnabled = data.enabled !== false;

    if (spoilerData && spoilerData.teams) {
      blockedTeams = spoilerData.teams.filter(t => selectedIds.has(t.espnId));
    }

    if (callback) callback();
  });
}

// Check if text matches any blocked team
function matchesBlockedTeam(text) {
  if (!text) return null;
  const lower = text.toLowerCase();

  for (const team of blockedTeams) {
    if (team.keywords.strong.some(k => lower.includes(k))) return team;

    if (team.keywords.weak.some(k => lower.includes(k))) {
      const teamWords = [
        team.displayName.toLowerCase(),
        team.name.toLowerCase(),
        team.abbreviation.toLowerCase()
      ];
      if (teamWords.some(w => lower.includes(w))) return team;
    }
  }
  return null;
}

function getCardText(el) {
  const title = el.querySelector([
    '#video-title',
    'h3 a',
    'a#video-title',
    '#movie-name',
    '.title',
    '.ytd-watch-card-compact-video-renderer #video-title',
    '.shortsLockupViewModelHostOutsideMetadata',
    '.shortsLockupViewModelHostMetadataTitle',
    'h3.shortsLockupViewModelHostOutsideMetadataTitle',
    '.reel-item-metadata h3',
    '#details .title',
    'a.yt-simple-endpoint.ytd-playlist-renderer',
    '.playlist-title',
    'yt-formatted-string.ytd-video-renderer',
    'span#video-title'
  ].join(', '));

  const channel = el.querySelector([
    '#channel-name',
    'ytd-channel-name',
    '.ytd-channel-name',
    'a.yt-simple-endpoint.ytd-video-owner-renderer',
    '.shortsLockupViewModelHostOutsideMetadataSubtitle',
    '#owner-name'
  ].join(', '));

  const description = el.querySelector([
    '#description-text',
    '#snippet-text',
    'yt-formatted-string#description-text',
    '.metadata-snippet-text',
    '#description'
  ].join(', '));

  const metadata = el.querySelector([
    '#metadata-line',
    '#video-short-byline-text',
    '.ytd-video-meta-block',
    '#metadata'
  ].join(', '));

  const shortTitle = el.querySelector([
    '.reel-item-metadata',
    '#details',
    'h3.shortsLockupViewModelHostOutsideMetadataTitle',
    '.shortsLockupViewModelHostOutsideMetadata'
  ].join(', '));

  return [
    title?.textContent || '',
    channel?.textContent || '',
    description?.textContent || '',
    metadata?.textContent || '',
    shortTitle?.textContent || '',
    el.getAttribute('aria-label') || '',
    el.getAttribute('title') || ''
  ].join(' ').trim();
}

function applyBlur(el, team) {
  if (el.dataset.ssBlurred === 'true') return;
  el.dataset.ssBlurred = 'true';
  el.dataset.ssTeam = team.espnId;
  el.style.position = 'relative';
  el.style.overflow = 'hidden';
  el.style.filter = 'blur(10px)';

  const overlay = document.createElement('div');
  overlay.className = 'ss-overlay';
  overlay.style.filter = 'blur(0px)';
  overlay.innerHTML = `
    <div class="ss-overlay-inner">
      <div class="ss-lock">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" 
          stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
          <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
        </svg>
      </div>
      <div class="ss-label">Spoiler Blocked</div>
    </div>
  `;

  overlay.addEventListener('click', e => {
    e.preventDefault();
    e.stopPropagation();
    showConfirmation(el, overlay, team);
  });

  el.appendChild(overlay);
}

function showConfirmation(el, overlay, team) {
  document.querySelector('.ss-dialog')?.remove();

  const dialog = document.createElement('div');
  dialog.className = 'ss-dialog';
  dialog.innerHTML = `
    <div class="ss-dialog-box">
      <div class="ss-dialog-emoji">🏀</div>
      <h3>Watch this video?</h3>
      <p>This video may contain spoilers for<br>
      <strong>${team.displayName}</strong></p>
      <div class="ss-dialog-buttons">
        <button class="ss-btn-cancel">Keep Blocked</button>
        <button class="ss-btn-confirm">Watch Anyway</button>
      </div>
    </div>
  `;

  document.body.appendChild(dialog);

  dialog.querySelector('.ss-btn-cancel').addEventListener('click', () => {
    dialog.remove();
  });

  dialog.querySelector('.ss-btn-confirm').addEventListener('click', () => {
    dialog.remove();
    overlay.remove();
    el.style.filter = 'none';
    el.dataset.ssBlurred = 'removed';
  });

  dialog.addEventListener('click', e => {
    if (e.target === dialog) dialog.remove();
  });
}

function scanPage() {
  const selectors = [
    'ytd-rich-item-renderer',
    'ytd-video-renderer',
    'ytd-compact-video-renderer',
    'ytd-grid-video-renderer',
    'ytd-video-with-context-renderer',
    'ytd-reel-item-renderer',
    'ytd-shorts',
    'ytd-reel-shelf-renderer',
    'ytm-shorts-lockup-view-model',
    'ytm-shorts-lockup-view-model-v2',
    'ytd-playlist-renderer',
    'ytd-compact-playlist-renderer',
    'ytd-grid-playlist-renderer',
    'ytd-radio-renderer',
    'ytd-compact-radio-renderer',
    'ytd-watch-card-compact-video-renderer',
    'ytd-watch-card-rich-header-renderer',
    'ytd-movie-renderer',
    'ytd-clip-creation-renderer',
    'ytd-search-pyv-renderer',
    'ytd-notification-renderer',
    'ytd-compact-live-meta-renderer',
    'ytd-channel-video-player-renderer',
    'ytd-featured-channel-renderer'
  ].join(', ');

  const cards = document.querySelectorAll(selectors);

  if (cards.length === 0) return;

  if (!isEnabled || blockedTeams.length === 0) {
    scanComplete = true;
    removeShield();
    return;
  }

  cards.forEach(el => {
    if (el.dataset.ssBlurred === 'true') return;
    if (el.dataset.ssBlurred === 'removed') return;

    const text = getCardText(el);

    if (!text) {
      el.classList.add('ss-scanned');
      return;
    }

    const team = matchesBlockedTeam(text);
    if (team) {
      applyBlur(el, team);
    } else {
      el.classList.add('ss-scanned');
    }
  });

  scanComplete = true;
  removeShield();
}

function fullReset() {
  scanComplete = false;
  document.querySelectorAll('[data-ss-blurred="true"], .ss-scanned').forEach(el => {
    el.querySelector('.ss-overlay')?.remove();
    el.style.filter = 'none';
    el.dataset.ssBlurred = '';
    el.classList.remove('ss-scanned');
  });

  loadSettings(() => scanPage());
}

const observer = new MutationObserver(() => {
  clearTimeout(window._ssScanTimer);
  window._ssScanTimer = setTimeout(scanPage, 200);
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'RESCAN') fullReset();
});

// Init — only inject shield if teams are selected
chrome.storage.local.get(['selectedTeams', 'enabled'], data => {
  const selectedTeams = data.selectedTeams || [];
  const enabled = data.enabled !== false;

  if (selectedTeams.length > 0 && enabled) {
    injectShield();
  } else {
    scanComplete = true;
    shieldRemoved = true;
  }

  loadSettings(() => scanPage());
});